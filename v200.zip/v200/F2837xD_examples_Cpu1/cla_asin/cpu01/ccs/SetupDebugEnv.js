// Add watch window variables and graphs
expRemoveAll
expAdd("pass",getNatural())
expAdd("fail",getNatural())
expAdd("fVal",getNatural())
expAdd("fResult",getNatural())
