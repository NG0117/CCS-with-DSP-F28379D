//Add watch window variables
expRemoveAll
expAdd("pass",getNatural())
expAdd("fail",getNatural())
expAdd("cla_fail_count",getNatural())
expAdd("cla_pass_count",getNatural())


