//Add watch window variables
expRemoveAll
expAdd("pass",getNatural())
expAdd("fail",getNatural())
expAdd("Num",getNatural())
expAdd("Den",getNatural())
expAdd("ExpRes",getNatural())
