// Add watch window variables and graphs
expRemoveAll
expAdd("table", getHex())
expAdd("pass", getNatural())
expAdd("fail", getNatural())