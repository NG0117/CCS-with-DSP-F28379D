//Add watch window variables
expRemoveAll
expAdd("pass",getNatural())
expAdd("fail",getNatural())
expAdd("x",getNatural())
expAdd("z",getNatural())



