//Add watch window variables
expRemoveAll
expAdd("pass",getNatural())
expAdd("fail",getNatural())
expAdd("z",getNatural())
expAdd("fDet",getNatural())
