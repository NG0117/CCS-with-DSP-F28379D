//Add Watch window Variables
expRemoveAll()
expAdd ("low_limit")
expAdd ("high_limit")